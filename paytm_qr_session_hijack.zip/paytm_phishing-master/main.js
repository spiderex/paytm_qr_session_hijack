setTimeout(function(){
   window.location.reload(1);
}, 20000);
